<div id="sidebar">
						<div id="search">
							<h2>Search</h2>
							<form method="get" action="">
								<fieldset>
									<input type="text" name="s" id="search-text" size="15" value="enter keywords here..." />
									<input type="submit" id="search-submit" value="GO" />
								</fieldset>
							</form>
						</div>
						<?php dynamic_sidebar(); ?>
					</div>
					<!-- end #sidebar -->