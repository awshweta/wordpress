<?php

/**
 * Fired during plugin activation
 *
 * @link       Cedcoss
 * @since      1.0.0
 *
 * @package    Cedboiler
 * @subpackage Cedboiler/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Cedboiler
 * @subpackage Cedboiler/includes
 * @author     Shweta Awasthi <shwetaawasthi@cedcoss.com>
 */
class Cedboiler_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
